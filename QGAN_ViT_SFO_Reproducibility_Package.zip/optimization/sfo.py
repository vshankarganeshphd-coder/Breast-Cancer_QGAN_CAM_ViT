import numpy as np

class SharpbellyFishOptimizer:
    """
    Reproducibility implementation interface for the SFO search stage.

    IMPORTANT:
    Replace the update equations below with the exact SFO equations from
    the authors' original implementation if the paper's source code is
    available. The manuscript specifies population size=30 and iterations=50,
    but does not expose sufficient numerical update detail to reconstruct
    the historical optimizer exactly.
    """
    def __init__(self,bounds,population_size=30,iterations=50,seed=42):
        self.bounds=np.asarray(bounds,dtype=float)
        self.population_size=population_size
        self.iterations=iterations
        self.rng=np.random.default_rng(seed)

    def initialize(self):
        lo=self.bounds[:,0]; hi=self.bounds[:,1]
        return self.rng.uniform(lo,hi,
            size=(self.population_size,len(self.bounds)))

    def optimize(self,objective):
        pop=self.initialize()
        scores=np.array([objective(x) for x in pop])
        best=pop[np.argmin(scores)].copy()
        best_score=float(scores.min())
        for _ in range(self.iterations):
            lo=self.bounds[:,0]; hi=self.bounds[:,1]
            candidate=pop + self.rng.normal(0,0.1,pop.shape)*(hi-lo)
            candidate=np.clip(candidate,lo,hi)
            cs=np.array([objective(x) for x in candidate])
            improved=cs<scores
            pop[improved]=candidate[improved]
            scores[improved]=cs[improved]
            j=np.argmin(scores)
            if scores[j]<best_score:
                best=pop[j].copy()
                best_score=float(scores[j])
        return best,best_score
