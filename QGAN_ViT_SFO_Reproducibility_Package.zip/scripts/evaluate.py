import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score,confusion_matrix,roc_auc_score

from config import CFG
from data.dataset import BUSIUDataset
from models.qgan_vit_sfo import QGANViTSFO

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--manifest",required=True)
    ap.add_argument("--checkpoint",default="checkpoints/best_model.pth")
    args=ap.parse_args()

    device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    df=pd.read_csv(args.manifest)
    ds=BUSIUDataset(df.to_dict("records"),CFG.image_size,False)
    loader=DataLoader(ds,batch_size=CFG.batch_size,shuffle=False)

    model=QGANViTSFO().to(device)
    ckpt=torch.load(args.checkpoint,map_location=device)
    model.generator.load_state_dict(ckpt["generator"])
    model.eval()

    yt=[]; yp=[]; probs=[]
    dice=[]; iou=[]; specificity=[]

    with torch.no_grad():
        for x,m,y in loader:
            x=x.to(device); m=m.to(device)
            seg,logits=model.generator(x)
            p=torch.softmax(logits,1)
            pred=p.argmax(1)
            yt.extend(y.numpy()); yp.extend(pred.cpu().numpy())
            probs.extend(p.cpu().numpy())

            seg=(seg>0.5).float()
            for i in range(len(y)):
                a=seg[i].flatten(); b=m[i].flatten()
                tp=(a*b).sum().item()
                fp=(a*(1-b)).sum().item()
                fn=((1-a)*b).sum().item()
                tn=((1-a)*(1-b)).sum().item()
                dice.append((2*tp+1e-8)/(2*tp+fp+fn+1e-8))
                iou.append((tp+1e-8)/(tp+fp+fn+1e-8))
                specificity.append((tn+1e-8)/(tn+fp+1e-8))

    result={
        "accuracy":accuracy_score(yt,yp),
        "precision_macro":precision_score(yt,yp,average="macro",zero_division=0),
        "recall_macro":recall_score(yt,yp,average="macro",zero_division=0),
        "f1_macro":f1_score(yt,yp,average="macro",zero_division=0),
        "dice":float(np.mean(dice)),
        "iou":float(np.mean(iou)),
        "specificity":float(np.mean(specificity)),
        "trainable_parameters":sum(p.numel() for p in model.generator.parameters() if p.requires_grad)
    }
    cm=confusion_matrix(yt,yp)
    Path(CFG.output_dir).mkdir(exist_ok=True)
    json.dump(result,open(Path(CFG.output_dir)/"metrics.json","w"),indent=2)
    np.save(Path(CFG.output_dir)/"confusion_matrix.npy",cm)
    print(json.dumps(result,indent=2))
    print(cm)

if __name__=="__main__":
    main()
