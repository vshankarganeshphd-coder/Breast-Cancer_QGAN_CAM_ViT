import argparse, json, time, random
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
from sklearn.model_selection import train_test_split

from config import CFG
from data.dataset import BUSIUDataset
from models.qgan_vit_sfo import QGANViTSFO
from losses.losses import CombinedGeneratorLoss

def seed_everything(seed):
    random.seed(seed); np.random.seed(seed)
    torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic=True
    torch.backends.cudnn.benchmark=False

def validate(model,loader,device):
    model.eval()
    total=0; correct=0; loss_sum=0
    criterion=torch.nn.CrossEntropyLoss()
    with torch.no_grad():
        for x,m,y in loader:
            x=x.to(device); y=y.to(device)
            _,logits=model.generator(x)
            loss_sum+=criterion(logits,y).item()
            correct+=(logits.argmax(1)==y).sum().item()
            total+=len(y)
    return loss_sum/max(1,len(loader)),correct/max(1,total)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--manifest",required=True)
    args=ap.parse_args()

    seed_everything(CFG.seed)
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu")

    df=pd.read_csv(args.manifest)
    train_df,val_df=train_test_split(
        df,test_size=0.2,random_state=CFG.seed,
        stratify=df["label"]
    )

    train_ds=BUSIUDataset(train_df.to_dict("records"),CFG.image_size,True)
    val_ds=BUSIUDataset(val_df.to_dict("records"),CFG.image_size,False)

    train_loader=DataLoader(train_ds,batch_size=CFG.batch_size,
        shuffle=True,num_workers=CFG.num_workers,pin_memory=True)
    val_loader=DataLoader(val_ds,batch_size=CFG.batch_size,
        shuffle=False,num_workers=CFG.num_workers,pin_memory=True)

    model=QGANViTSFO().to(device)

    optG=torch.optim.AdamW(model.generator.parameters(),
        lr=CFG.learning_rate,weight_decay=CFG.weight_decay)
    optD=torch.optim.AdamW(model.discriminator.parameters(),
        lr=CFG.learning_rate,weight_decay=CFG.weight_decay)

    schedG=torch.optim.lr_scheduler.ReduceLROnPlateau(
        optG,mode="min",factor=0.5,patience=10)
    schedD=torch.optim.lr_scheduler.ReduceLROnPlateau(
        optD,mode="min",factor=0.5,patience=10)

    criterion=CombinedGeneratorLoss(
        CFG.segmentation_loss_weight,
        CFG.classification_loss_weight
    )
    adv=torch.nn.BCEWithLogitsLoss()

    scaler=torch.cuda.amp.GradScaler(enabled=device.type=="cuda")

    best=float("inf"); patience=0
    history=[]

    Path(CFG.checkpoint_dir).mkdir(exist_ok=True)

    for epoch in range(CFG.epochs):
        model.train()
        running=0

        for x,m,y in train_loader:
            x=x.to(device); m=m.to(device); y=y.to(device)

            # discriminator
            optD.zero_grad(set_to_none=True)
            with torch.cuda.amp.autocast(enabled=device.type=="cuda"):
                fake,_=model.generator(x)
                real_out=model.discriminator(x,m)
                fake_out=model.discriminator(x,fake.detach())
                dloss=0.5*(
                    adv(real_out,torch.ones_like(real_out))+
                    adv(fake_out,torch.zeros_like(fake_out))
                )
            scaler.scale(dloss).backward()
            scaler.step(optD); scaler.update()

            # generator
            optG.zero_grad(set_to_none=True)
            with torch.cuda.amp.autocast(enabled=device.type=="cuda"):
                pred,logits=model.generator(x)
                fake_out=model.discriminator(x,pred)
                total,ld,lc,la=criterion(pred,m,logits,y,fake_out)
            scaler.scale(total).backward()
            scaler.step(optG); scaler.update()
            running+=total.item()

        vl,va=validate(model,val_loader,device)
        schedG.step(vl); schedD.step(vl)

        rec={
            "epoch":epoch+1,
            "train_loss":running/max(1,len(train_loader)),
            "val_loss":vl,
            "val_accuracy":va,
            "learning_rate":optG.param_groups[0]["lr"]
        }
        history.append(rec)
        print(rec)

        if vl<best:
            best=vl; patience=0
            torch.save({
                "epoch":epoch+1,
                "generator":model.generator.state_dict(),
                "discriminator":model.discriminator.state_dict(),
                "optimizer_G":optG.state_dict(),
                "optimizer_D":optD.state_dict(),
                "history":history
            },Path(CFG.checkpoint_dir)/"best_model.pth")
        else:
            patience+=1
            if patience>=CFG.early_stopping_patience:
                print("Early stopping.")
                break

    Path(CFG.output_dir).mkdir(exist_ok=True)
    json.dump(history,open(Path(CFG.output_dir)/"training_history.json","w"),indent=2)

if __name__=="__main__":
    main()
