import torch
import torch.nn as nn

class DiceLoss(nn.Module):
    def forward(self,pred,target):
        smooth=1e-6
        pred=pred.reshape(pred.size(0),-1)
        target=target.reshape(target.size(0),-1)
        inter=(pred*target).sum(1)
        dice=(2*inter+smooth)/(pred.sum(1)+target.sum(1)+smooth)
        return 1-dice.mean()

class CombinedGeneratorLoss(nn.Module):
    def __init__(self,seg_weight=0.6,cls_weight=0.4,adv_weight=0.1):
        super().__init__()
        self.seg_weight=seg_weight
        self.cls_weight=cls_weight
        self.adv_weight=adv_weight
        self.dice=DiceLoss()
        self.cls=nn.CrossEntropyLoss()
        self.adv=nn.BCEWithLogitsLoss()

    def forward(self,seg_pred,seg_true,class_logits,class_true,disc_fake):
        ld=self.dice(seg_pred,seg_true)
        lc=self.cls(class_logits,class_true)
        la=self.adv(disc_fake,torch.ones_like(disc_fake))
        total=self.seg_weight*ld+self.cls_weight*lc+self.adv_weight*la
        return total,ld,lc,la
