import torch
import torch.nn as nn
import torch.nn.functional as F
from config import CFG

class QFA(nn.Module):
    def __init__(self, channels, scale=1.75):
        super().__init__()
        self.scale = scale
        self.proj = nn.Linear(channels, channels, bias=False)
        self.norm = nn.LayerNorm(channels)
        self.gate = nn.Sequential(nn.Linear(channels, channels), nn.Sigmoid())
        nn.init.orthogonal_(self.proj.weight)

    def forward(self, x):
        b,c,_,_ = x.shape
        z = self.norm(x.mean(dim=(2,3)))
        q = self.proj(z)
        a = torch.softmax(q*self.scale, dim=1)
        g = self.gate(z)
        return x * (a*g).view(b,c,1,1) + x

class CAM(nn.Module):
    def __init__(self, channels, reduction=16):
        super().__init__()
        hidden=max(channels//reduction,4)
        self.mlp=nn.Sequential(
            nn.Linear(channels,hidden), nn.ReLU(inplace=True),
            nn.Linear(hidden,channels)
        )
    def forward(self,x):
        avg=F.adaptive_avg_pool2d(x,1).flatten(1)
        mx=F.adaptive_max_pool2d(x,1).flatten(1)
        a=torch.sigmoid(self.mlp(avg)+self.mlp(mx))
        return x*a.view(x.size(0),x.size(1),1,1)+x

class ConvBlock(nn.Module):
    def __init__(self,ci,co):
        super().__init__()
        self.net=nn.Sequential(
            nn.Conv2d(ci,co,3,padding=1,bias=False),
            nn.BatchNorm2d(co), nn.ReLU(inplace=True),
            nn.Conv2d(co,co,3,padding=1,bias=False),
            nn.BatchNorm2d(co), nn.ReLU(inplace=True)
        )
    def forward(self,x): return self.net(x)

class EncoderBlock(nn.Module):
    def __init__(self,ci,co):
        super().__init__()
        self.conv=ConvBlock(ci,co)
        self.qfa=QFA(co,CFG.qfa_scale)
        self.cam=CAM(co,CFG.cam_reduction)
    def forward(self,x):
        return self.cam(self.qfa(self.conv(x)))

class MSFF(nn.Module):
    def __init__(self,channels):
        super().__init__()
        self.d1=nn.Conv2d(channels,channels,3,padding=1,dilation=1)
        self.d2=nn.Conv2d(channels,channels,3,padding=2,dilation=2)
        self.d3=nn.Conv2d(channels,channels,3,padding=4,dilation=4)
        self.fuse=nn.Sequential(
            nn.Conv2d(channels*3,channels,1,bias=False),
            nn.BatchNorm2d(channels),nn.ReLU(inplace=True)
        )
    def forward(self,x):
        return self.fuse(torch.cat([self.d1(x),self.d2(x),self.d3(x)],1))+x

class DecoderBlock(nn.Module):
    def __init__(self,ci,skip,co):
        super().__init__()
        self.up=nn.ConvTranspose2d(ci,co,2,stride=2)
        self.conv=ConvBlock(co+skip,co)
    def forward(self,x,skip):
        x=self.up(x)
        if x.shape[-2:]!=skip.shape[-2:]:
            x=F.interpolate(x,size=skip.shape[-2:],mode="bilinear",align_corners=False)
        return self.conv(torch.cat([x,skip],1))

class ViTHead(nn.Module):
    def __init__(self,in_ch,embed=256,depth=6,heads=8,patch=16,dropout=0.25,num_classes=3):
        super().__init__()
        self.proj=nn.Conv2d(in_ch,embed,kernel_size=patch,stride=patch)
        layer=nn.TransformerEncoderLayer(
            d_model=embed,nhead=heads,dim_feedforward=embed*4,
            dropout=dropout,batch_first=True,activation="gelu",
            norm_first=True
        )
        self.encoder=nn.TransformerEncoder(layer,num_layers=depth)
        self.norm=nn.LayerNorm(embed)
        self.fc=nn.Linear(embed,num_classes)
    def forward(self,x):
        z=self.proj(x).flatten(2).transpose(1,2)
        z=self.encoder(z)
        return self.fc(self.norm(z.mean(1)))

class QGANGenerator(nn.Module):
    def __init__(self):
        super().__init__()
        self.e1=EncoderBlock(1,32)
        self.e2=EncoderBlock(32,64)
        self.e3=EncoderBlock(64,128)
        self.e4=EncoderBlock(128,256)
        self.pool=nn.MaxPool2d(2)
        self.msff=MSFF(256)
        self.d3=DecoderBlock(256,256,128)
        self.d2=DecoderBlock(128,128,64)
        self.d1=DecoderBlock(64,64,32)
        self.out=nn.Conv2d(32,1,1)
        self.cls=ViTHead(256,CFG.embed_dim,CFG.transformer_depth,
                         CFG.attention_heads,CFG.patch_size,
                         CFG.dropout,CFG.num_classes)

    def forward(self,x):
        e1=self.e1(x)
        e2=self.e2(self.pool(e1))
        e3=self.e3(self.pool(e2))
        e4=self.e4(self.pool(e3))
        b=self.msff(self.pool(e4))
        d3=self.d3(b,e4)
        d2=self.d2(d3,e3)
        d1=self.d1(d2,e2)
        seg=self.out(d1)
        seg=F.interpolate(seg,size=x.shape[-2:],mode="bilinear",align_corners=False)
        return torch.sigmoid(seg),self.cls(b)

class QGANDiscriminator(nn.Module):
    def __init__(self):
        super().__init__()
        def block(ci,co):
            return nn.Sequential(
                nn.Conv2d(ci,co,4,2,1),
                nn.BatchNorm2d(co),
                nn.LeakyReLU(0.2,inplace=True)
            )
        self.net=nn.Sequential(
            block(2,64),block(64,128),block(128,256),
            block(256,512),nn.Conv2d(512,1,4,1,0)
        )
    def forward(self,img,mask):
        return self.net(torch.cat([img,mask],1))

class QGANViTSFO(nn.Module):
    def __init__(self):
        super().__init__()
        self.generator=QGANGenerator()
        self.discriminator=QGANDiscriminator()
    def forward(self,x):
        return self.generator(x)
