import argparse
import torch

from config import CFG
from models.qgan_vit_sfo import QGANViTSFO

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--batch-size",type=int,default=1)
    args=ap.parse_args()

    device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model=QGANViTSFO().to(device).eval()

    params=sum(p.numel() for p in model.parameters() if p.requires_grad)
    model_size=params*4/(1024**2)

    x=torch.randn(args.batch_size,1,CFG.image_size,CFG.image_size,device=device)

    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
        with torch.no_grad():
            model(x)
        memory=torch.cuda.max_memory_allocated()/1024**3
        print(f"Peak GPU memory: {memory:.3f} GB")

    print(f"Trainable parameters: {params:,}")
    print(f"Approximate FP32 parameter size: {model_size:.3f} MB")

    try:
        from fvcore.nn import FlopCountAnalysis
        flops=FlopCountAnalysis(model,x).total()/1e9
        print(f"FLOPs: {flops:.3f} GFLOPs")
    except Exception as e:
        print("Install fvcore to calculate FLOPs:",e)

if __name__=="__main__":
    main()
