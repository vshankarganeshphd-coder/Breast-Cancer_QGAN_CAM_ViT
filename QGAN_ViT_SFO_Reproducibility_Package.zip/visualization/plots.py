import json, argparse
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay, roc_curve, auc

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--history",default="results/training_history.json")
    ap.add_argument("--cm",default="results/confusion_matrix.npy")
    args=ap.parse_args()

    out=Path("results/figures"); out.mkdir(parents=True,exist_ok=True)
    h=json.load(open(args.history))
    epochs=[x["epoch"] for x in h]

    plt.figure()
    plt.plot(epochs,[x["train_loss"] for x in h],label="Training Loss")
    plt.plot(epochs,[x["val_loss"] for x in h],label="Validation Loss")
    plt.xlabel("Epoch"); plt.ylabel("Loss"); plt.legend()
    plt.tight_layout(); plt.savefig(out/"training_validation_loss.png",dpi=300)
    plt.close()

    plt.figure()
    plt.plot(epochs,[x["val_accuracy"] for x in h],label="Validation Accuracy")
    plt.xlabel("Epoch"); plt.ylabel("Accuracy"); plt.legend()
    plt.tight_layout(); plt.savefig(out/"validation_accuracy.png",dpi=300)
    plt.close()

    cm=np.load(args.cm)
    disp=ConfusionMatrixDisplay(cm)
    disp.plot()
    plt.tight_layout(); plt.savefig(out/"confusion_matrix.png",dpi=300)
    plt.close()

if __name__=="__main__":
    main()
